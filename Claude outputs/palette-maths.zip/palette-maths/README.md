# Palette maths

Petite fenêtre flottante pour Mac. Elle reste toujours au premier plan et ne vole jamais le curseur. Un clic sur un symbole l'écrit directement dans Word, Pages ou n'importe quel traitement de texte.

Trois onglets en haut : **Universel** (symboles simples qui marchent partout), **Word** (fractions, racines, puissances au format de l'éditeur d'équations de Word) et **Pages** (même chose au format de l'éditeur d'équations de Pages).

---

## Partie 1 — Pour l'enseignant : compiler l'application

À faire une seule fois, sur ton Mac.

1. Installe les outils de développement Apple (gratuits) si ce n'est pas déjà fait. Dans le Terminal :
   `xcode-select --install`
   puis accepte l'installation (quelques minutes).
2. Place ce dossier où tu veux, ouvre le Terminal dans ce dossier et lance :
   `./build.sh`
3. Le Finder s'ouvre sur le dossier `build` qui contient **Palette maths.app**.
4. Clic droit sur `Palette maths.app` → **Compresser**. Tu obtiens `Palette maths.zip` : c'est ce fichier que tu donnes à l'élève (AirDrop, clé USB, mail, Teams…).

Pour modifier la palette plus tard (ajouter un symbole, changer un texte) : édite `main.swift` dans la partie `Catalogue`, relance `./build.sh`, redistribue le zip.

---

## Partie 2 — Pour l'élève : installer la palette

1. Double-clique sur `Palette maths.zip`. Glisse **Palette maths** dans le dossier **Applications**.
2. Première ouverture : double-clique sur l'app. macOS affiche un message disant qu'elle ne peut pas être ouverte (elle n'est pas enregistrée chez Apple, c'est normal). Clique sur **Terminé**, puis ouvre **Réglages Système → Confidentialité et sécurité**, descends en bas de la page et clique sur **Ouvrir quand même** à côté de « Palette maths ». Confirme avec ton mot de passe.
   *Variante sur les Mac plus anciens : clic droit sur l'app → Ouvrir → Ouvrir.*
3. La palette demande alors une autorisation d'**accessibilité**. C'est obligatoire : c'est ce qui lui permet d'écrire les symboles à ta place. Clique sur **Ouvrir les réglages**, active l'interrupteur à côté de **Palette maths**, puis quitte la palette (⌘Q) et relance-la.
4. C'est fini. La palette s'ouvre à droite de l'écran. Elle est aussi accessible par l'icône **ƒ** dans la barre de menus en haut à droite (un clic l'affiche ou la masque).

---

## Partie 3 — Utiliser la palette pendant un test

Ouvre ton document, mets le curseur là où tu veux écrire, puis clique sur les symboles. Le texte apparaît comme si tu l'avais tapé.

**Onglet Universel** (par défaut) : tout s'insère directement dans le texte. Les fractions simples (½, ¾), les carrés et cubes (², ³), les lettres grecques, les notations [AB], (AB), ∥, ⊥, °, les flèches ⟹ et ⟺, et des débuts de phrases pour le raisonnement (Hypothèse / Calcul / Conclusion, Pythagore, Thalès). Pour mettre un trait, un chapeau ou une flèche de vecteur sur une lettre : tape la lettre, puis clique sur le bouton. Pour AB avec flèche : tape A, clique, tape B, clique.

**Onglet Word** : pour les vrais calculs à étages (fractions, racines, puissances, vecteurs). Clique sur **Nouvelle équation** (ou appuie sur ⌃= dans Word), puis sur les boutons. Word construit la fraction ou la racine quand tu appuies sur **Espace**. Exemple d'une fraction : clique a/b, tape 3, flèche droite deux fois, tape 4, Espace.

**Onglet Pages** : même principe. Clique sur **Nouvelle équation** (ou ⌥⌘E dans Pages), clique sur les boutons, tape les nombres, puis clique sur **Insérer**.

**Roue dentée** (en haut à droite de la palette) : boutons plus grands ou plus petits. Si dans une application les symboles n'apparaissent pas, coche « Insérer via le presse-papiers » : la palette utilisera alors le copier-coller.

La palette mémorise sa position, sa taille et l'onglet choisi.

---

## En cas de problème

- **Rien ne s'écrit quand je clique** : l'autorisation d'accessibilité n'est pas donnée. Menu « Palette maths » → « Vérifier l'accessibilité ». Après avoir activé l'interrupteur, quitter et relancer la palette.
- **Le bouton « Nouvelle équation » ne fait rien dans Word** : utilise le menu Insertion → Équation de Word, ou le raccourci ⌃= (sur certains claviers, ⌃ + la touche =). Le reste de la palette fonctionne quand même.
- **Les symboles sortent dans le désordre ou avec des caractères bizarres** : cocher « Insérer via le presse-papiers » dans la roue dentée.
- **L'app refuse de s'ouvrir même après « Ouvrir quand même »** : dans le Terminal, `xattr -dr com.apple.quarantine "/Applications/Palette maths.app"` puis réessayer.
