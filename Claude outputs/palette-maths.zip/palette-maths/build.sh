#!/bin/bash
# Compile « Palette maths » en application macOS (binaire universel Intel + Apple Silicon).
# Prérequis : les outils de développement Apple (gratuits) :  xcode-select --install
# Usage :  ./build.sh
set -e
cd "$(dirname "$0")"

APP="build/Palette maths.app"
MACOS="$APP/Contents/MacOS"
RES="$APP/Contents/Resources"

echo "→ Préparation du bundle"
rm -rf build
mkdir -p "$MACOS" "$RES"

echo "→ Compilation (Apple Silicon)"
swiftc -O -target arm64-apple-macos13.0 -o build/PaletteMaths-arm64 main.swift
echo "→ Compilation (Intel)"
swiftc -O -target x86_64-apple-macos13.0 -o build/PaletteMaths-x86_64 main.swift
echo "→ Fusion en binaire universel"
lipo -create build/PaletteMaths-arm64 build/PaletteMaths-x86_64 -output "$MACOS/PaletteMaths"
rm build/PaletteMaths-arm64 build/PaletteMaths-x86_64

cp Info.plist "$APP/Contents/Info.plist"
echo "APPL????" > "$APP/Contents/PkgInfo"

if [ -f icon.png ]; then
  echo "→ Icône"
  ICONSET="build/AppIcon.iconset"
  mkdir -p "$ICONSET"
  for s in 16 32 128 256 512; do
    sips -z $s $s icon.png --out "$ICONSET/icon_${s}x${s}.png" >/dev/null
    d=$((s*2))
    sips -z $d $d icon.png --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null
  done
  iconutil -c icns "$ICONSET" -o "$RES/AppIcon.icns"
  rm -rf "$ICONSET"
fi

echo "→ Signature ad hoc (stabilise l'autorisation d'accessibilité)"
codesign --force --deep --sign - "$APP"

echo
echo "✔ Terminé : $APP"
echo "  Pour la distribuer : compresse le dossier « build/Palette maths.app » en .zip (clic droit → Compresser)."
open build
