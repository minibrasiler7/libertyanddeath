// Palette maths — palette flottante de symboles mathématiques pour macOS
// Un seul fichier Swift. Compilation : ./build.sh (voir README.md)
//
// Principe : une petite fenêtre toujours au premier plan, qui ne vole jamais
// le focus. Un clic sur un bouton "tape" le symbole dans l'application active
// (Word, Pages, Notes…) grâce à l'accessibilité macOS.

import Cocoa
import SwiftUI

// MARK: - Modèle

enum Mode: String, CaseIterable, Identifiable {
    case universel = "Universel"
    case word = "Word"
    case pages = "Pages"
    var id: String { rawValue }
}

struct KeyPress {
    let code: CGKeyCode
    let flags: CGEventFlags
    let char: String?
}

struct Insertion {
    var text: String
    var left: Int = 0                 // nombre de "flèche gauche" après l'insertion (place le curseur)
    var preKeys: [KeyPress] = []      // raccourcis clavier envoyés avant le texte
    var note: String? = nil           // conseil affiché en bas de la palette
}

struct Item: Identifiable {
    let id = UUID()
    let label: String
    let help: String
    let universel: Insertion
    var word: Insertion? = nil
    var pages: Insertion? = nil

    func insertion(for mode: Mode) -> Insertion {
        switch mode {
        case .universel: return universel
        case .word: return word ?? universel
        case .pages: return pages ?? universel
        }
    }
}

struct PaletteSection: Identifiable {
    let id = UUID()
    let title: String
    let items: [Item]
}

// Raccourcis utiles
private func u(_ text: String, left: Int = 0, note: String? = nil) -> Insertion {
    Insertion(text: text, left: left, note: note)
}

private let noteWord = "Dans une équation Word (bouton « Nouvelle équation » ou ⌃=), puis appuie sur Espace."
private let notePages = "Dans une équation Pages (bouton « Nouvelle équation » ou ⌥⌘E)."

// Combinaisons de touches
let keyReturn: CGKeyCode = 36
let keyLeft: CGKeyCode = 123
let keyV: CGKeyCode = 9
let keyE: CGKeyCode = 14
let keyEqual: CGKeyCode = 24

func newEquation(for mode: Mode) -> Insertion {
    switch mode {
    case .word:
        return Insertion(text: "", preKeys: [KeyPress(code: keyEqual, flags: .maskControl, char: "=")],
                         note: "Nouvelle équation Word. Si rien ne se passe : menu Insertion → Équation (ou ⌃=).")
    case .pages:
        return Insertion(text: "", preKeys: [KeyPress(code: keyE, flags: [.maskCommand, .maskAlternate], char: nil)],
                         note: "Nouvelle équation Pages. Tape la formule, puis « Insérer ».")
    case .universel:
        return Insertion(text: "")
    }
}

// MARK: - Catalogue des boutons

enum Catalogue {
    static let sections: [PaletteSection] = [
        PaletteSection(title: "Calculs", items: calculs),
        PaletteSection(title: "Géométrie", items: geometrie),
        PaletteSection(title: "Raisonnement", items: raisonnement),
    ]

    static let calculs: [Item] = [
            Item(label: "×", help: "Multiplication", universel: u("×"), word: u("×"), pages: u("×")),
            Item(label: "÷", help: "Division", universel: u("÷")),
            Item(label: "±", help: "Plus ou moins", universel: u("±")),
            Item(label: "≠", help: "Différent de", universel: u("≠")),
            Item(label: "≤", help: "Inférieur ou égal", universel: u("≤")),
            Item(label: "≥", help: "Supérieur ou égal", universel: u("≥")),
            Item(label: "≈", help: "Environ égal", universel: u("≈")),
            Item(label: "a/b", help: "Fraction — tape le numérateur, flèche droite, le dénominateur",
                 universel: u("⁄", note: "Fraction simple : 3⁄4. Tape le haut, clique a/b, tape le bas."),
                 word: u("()/()", left: 4, note: "Fraction Word : tape le haut, flèche droite ×2, tape le bas, puis Espace. \(noteWord)"),
                 pages: u("\\frac{}{}", left: 3, note: "Fraction Pages : tape le haut, flèche droite ×2, tape le bas. \(notePages)")),
            Item(label: "½", help: "Un demi", universel: u("½")),
            Item(label: "¼", help: "Un quart", universel: u("¼")),
            Item(label: "¾", help: "Trois quarts", universel: u("¾")),
            Item(label: "x²", help: "Au carré (fonctionne aussi dans une équation)", universel: u("²")),
            Item(label: "x³", help: "Au cube (fonctionne aussi dans une équation)", universel: u("³")),
            Item(label: "xⁿ", help: "Puissance quelconque — tape l'exposant ensuite",
                 universel: u("^", note: "Puissance : écris par exemple 2^5 (ou utilise ² ³)."),
                 word: u("^()", left: 1, note: "Tape l'exposant entre les parenthèses, puis Espace. \(noteWord)"),
                 pages: u("^{}", left: 1, note: "Tape l'exposant entre les accolades. \(notePages)")),
            Item(label: "x₁", help: "Indice — tape l'indice ensuite",
                 universel: u("₁"),
                 word: u("_()", left: 1, note: noteWord),
                 pages: u("_{}", left: 1, note: notePages)),
            Item(label: "√", help: "Racine carrée",
                 universel: u("√"),
                 word: u("\\sqrt()", left: 1, note: "Tape ce qui est sous la racine, puis Espace. \(noteWord)"),
                 pages: u("\\sqrt{}", left: 1, note: notePages)),
            Item(label: "∛", help: "Racine cubique", universel: u("∛"),
                 word: u("\\cbrt()", left: 1, note: noteWord), pages: u("\\sqrt[3]{}", left: 1, note: notePages)),
            Item(label: "( )", help: "Parenthèses — le curseur est placé au milieu", universel: u("()", left: 1)),
            Item(label: "π", help: "Pi", universel: u("π"), pages: u("π")),
            Item(label: "∞", help: "Infini", universel: u("∞")),
            Item(label: "%", help: "Pour cent", universel: u("%")),
            Item(label: "cm²", help: "Centimètres carrés", universel: u("cm²"), word: u("cm²"), pages: u("cm²")),
            Item(label: "cm³", help: "Centimètres cubes", universel: u("cm³"), word: u("cm³"), pages: u("cm³")),
            Item(label: "·", help: "Point de multiplication", universel: u("·")),
        ]

    static let geometrie: [Item] = [
            Item(label: "[AB]", help: "Segment — tape les deux lettres entre les crochets", universel: u("[]", left: 1)),
            Item(label: "(AB)", help: "Droite — tape les deux lettres entre les parenthèses", universel: u("()", left: 1)),
            Item(label: "[AB)", help: "Demi-droite — tape les deux lettres", universel: u("[)", left: 1)),
            Item(label: "A̅B̅", help: "Trait au-dessus (longueur) — clique après chaque lettre",
                 universel: u("\u{0305}", note: "Trait au-dessus : tape A, clique, tape B, clique."),
                 word: u("()\\overbar", left: 9, note: "Tape les lettres entre les parenthèses, puis Espace. \(noteWord)"),
                 pages: u("\\overline{}", left: 1, note: notePages)),
            Item(label: "ÂBC", help: "Angle — accent circonflexe (chapeau)",
                 universel: u("\u{0302}", note: "Chapeau : tape la lettre du sommet, puis clique."),
                 word: u("∠"),
                 pages: u("\\widehat{}", left: 1, note: notePages)),
            Item(label: "∠", help: "Symbole angle", universel: u("∠")),
            Item(label: "AB⃗", help: "Vecteur — flèche au-dessus",
                 universel: u("\u{20D7}", note: "Flèche de vecteur : tape A, clique, tape B, clique."),
                 word: u("()\\vec", left: 5, note: "Tape les lettres entre les parenthèses, puis Espace. \(noteWord)"),
                 pages: u("\\vec{}", left: 1, note: notePages)),
            Item(label: "∥", help: "Parallèle", universel: u("∥"), pages: u("∥")),
            Item(label: "⊥", help: "Perpendiculaire", universel: u("⊥")),
            Item(label: "△", help: "Triangle", universel: u("△")),
            Item(label: "°", help: "Degré", universel: u("°")),
            Item(label: "≅", help: "Isométrique", universel: u("≅")),
            Item(label: "∼", help: "Semblable", universel: u("∼")),
            Item(label: "∈", help: "Appartient à", universel: u("∈")),
            Item(label: "∉", help: "N'appartient pas à", universel: u("∉")),
            Item(label: "α", help: "Alpha", universel: u("α")),
            Item(label: "β", help: "Bêta", universel: u("β")),
            Item(label: "γ", help: "Gamma", universel: u("γ")),
            Item(label: "θ", help: "Thêta", universel: u("θ")),
            Item(label: "Δ", help: "Delta", universel: u("Δ")),
            Item(label: "ℝ", help: "Nombres réels", universel: u("ℝ")),
            Item(label: "ℚ", help: "Nombres rationnels", universel: u("ℚ")),
            Item(label: "ℤ", help: "Nombres entiers relatifs", universel: u("ℤ")),
            Item(label: "ℕ", help: "Nombres naturels", universel: u("ℕ")),
        ]

    static let raisonnement: [Item] = [
            Item(label: "⟹", help: "Implique", universel: u(" ⟹ ")),
            Item(label: "⟺", help: "Équivaut à", universel: u(" ⟺ ")),
            Item(label: "Donc", help: "Donc", universel: u("Donc ")),
            Item(label: "Car", help: "Car", universel: u("car ")),
            Item(label: "D'où", help: "D'où", universel: u("D'où ")),
            Item(label: "Hyp.", help: "Hypothèse :", universel: u("Hypothèse : ")),
            Item(label: "Calcul", help: "Calcul :", universel: u("Calcul : ")),
            Item(label: "Concl.", help: "Conclusion :", universel: u("Conclusion : ")),
            Item(label: "Plan", help: "Structure complète : Hypothèse / Calcul / Conclusion",
                 universel: u("Hypothèse : \nCalcul : \nConclusion : ")),
            Item(label: "Pythagore", help: "Par le théorème de Pythagore…", universel: u("Par le théorème de Pythagore dans le triangle ")),
            Item(label: "Thalès", help: "D'après le théorème de Thalès…", universel: u("D'après le théorème de Thalès, ")),
            Item(label: "Réponse", help: "Réponse :", universel: u("Réponse : ")),
        ]
}

// MARK: - Frappe simulée

enum Typist {
    static var useClipboard = false
    private static let queue = DispatchQueue(label: "palette.typist")

    static func perform(_ ins: Insertion) {
        queue.async {
            for k in ins.preKeys {
                press(k)
                usleep(120_000)
            }
            if !ins.preKeys.isEmpty { usleep(400_000) }
            if !ins.text.isEmpty {
                if useClipboard { paste(ins.text) } else { typeText(ins.text) }
            }
            if ins.left > 0 {
                usleep(120_000)
                for _ in 0..<ins.left {
                    press(KeyPress(code: keyLeft, flags: [], char: nil))
                    usleep(20_000)
                }
            }
        }
    }

    static func press(_ k: KeyPress) {
        let src = CGEventSource(stateID: .combinedSessionState)
        guard let down = CGEvent(keyboardEventSource: src, virtualKey: k.code, keyDown: true),
              let up = CGEvent(keyboardEventSource: src, virtualKey: k.code, keyDown: false) else { return }
        down.flags = k.flags
        up.flags = k.flags
        if let c = k.char {
            var units = Array(c.utf16)
            down.keyboardSetUnicodeString(stringLength: units.count, unicodeString: &units)
            up.keyboardSetUnicodeString(stringLength: units.count, unicodeString: &units)
        }
        down.post(tap: .cghidEventTap)
        up.post(tap: .cghidEventTap)
    }

    /// Tape le texte caractère par caractère (fonctionne dans la plupart des applications).
    static func typeText(_ text: String) {
        let src = CGEventSource(stateID: .combinedSessionState)
        let lines = text.components(separatedBy: "\n")
        for (i, line) in lines.enumerated() {
            for scalar in line.unicodeScalars {
                var units = Array(String(scalar).utf16)
                guard let down = CGEvent(keyboardEventSource: src, virtualKey: 0, keyDown: true),
                      let up = CGEvent(keyboardEventSource: src, virtualKey: 0, keyDown: false) else { continue }
                down.keyboardSetUnicodeString(stringLength: units.count, unicodeString: &units)
                up.keyboardSetUnicodeString(stringLength: units.count, unicodeString: &units)
                down.post(tap: .cghidEventTap)
                up.post(tap: .cghidEventTap)
                usleep(12_000)
            }
            if i < lines.count - 1 {
                press(KeyPress(code: keyReturn, flags: [], char: nil))
                usleep(40_000)
            }
        }
    }

    /// Variante : passe par le presse-papiers et ⌘V (pour les applications récalcitrantes).
    static func paste(_ text: String) {
        var old: String?
        DispatchQueue.main.sync {
            let pb = NSPasteboard.general
            old = pb.string(forType: .string)
            pb.clearContents()
            pb.setString(text, forType: .string)
        }
        usleep(80_000)
        press(KeyPress(code: keyV, flags: .maskCommand, char: nil))
        usleep(800_000)
        DispatchQueue.main.async {
            if let old = old {
                let pb = NSPasteboard.general
                pb.clearContents()
                pb.setString(old, forType: .string)
            }
        }
    }
}

// MARK: - Interface

struct PaletteView: View {
    @AppStorage("mode") private var modeRaw = Mode.universel.rawValue
    @AppStorage("fontSize") private var fontSize = 20.0
    @AppStorage("useClipboard") private var useClipboard = false
    @State private var note = "Clique sur un symbole : il s'écrit là où est ton curseur."

    private var mode: Mode { Mode(rawValue: modeRaw) ?? .universel }

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 6) {
                Picker("", selection: $modeRaw) {
                    ForEach(Mode.allCases) { m in Text(m.rawValue).tag(m.rawValue) }
                }
                .pickerStyle(.segmented)
                .labelsHidden()

                Menu {
                    Button("Boutons plus grands") { fontSize = min(fontSize + 2, 40) }
                    Button("Boutons plus petits") { fontSize = max(fontSize - 2, 12) }
                    Divider()
                    Toggle("Insérer via le presse-papiers", isOn: $useClipboard)
                } label: {
                    Image(systemName: "gearshape")
                }
                .menuStyle(.borderlessButton)
                .frame(width: 28)
            }

            if mode != .universel {
                Button {
                    let ins = newEquation(for: mode)
                    Typist.perform(ins)
                    if let n = ins.note { note = n }
                } label: {
                    Label("Nouvelle équation", systemImage: "function")
                        .frame(maxWidth: .infinity)
                }
                .controlSize(.large)
            }

            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(Catalogue.sections) { section in
                        Text(section.title.uppercased())
                            .font(.caption.weight(.semibold))
                            .foregroundColor(.secondary)
                            .padding(.top, 4)
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: fontSize * 2.6), spacing: 6)], spacing: 6) {
                            ForEach(section.items) { item in
                                SymbolButton(item: item, mode: mode, fontSize: fontSize) { ins in
                                    note = ins.note ?? item.help
                                }
                            }
                        }
                    }
                }
                .padding(.bottom, 4)
            }

            Text(note)
                .font(.caption)
                .foregroundColor(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .lineLimit(3)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(10)
        .frame(minWidth: 280, minHeight: 360)
        .onAppear { Typist.useClipboard = useClipboard }
        .onChange(of: useClipboard) { v in Typist.useClipboard = v }
    }
}

struct SymbolButton: View {
    let item: Item
    let mode: Mode
    let fontSize: Double
    let onPress: (Insertion) -> Void

    var body: some View {
        Button {
            let ins = item.insertion(for: mode)
            Typist.perform(ins)
            onPress(ins)
        } label: {
            Text(item.label)
                .font(.system(size: fontSize))
                .lineLimit(1)
                .minimumScaleFactor(0.5)
                .frame(maxWidth: .infinity, minHeight: fontSize * 1.9)
        }
        .buttonStyle(.bordered)
        .help(item.help)
    }
}

// MARK: - Fenêtre flottante

final class PalettePanel: NSPanel {
    override var canBecomeMain: Bool { false }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var panel: PalettePanel!
    private var statusItem: NSStatusItem?

    func applicationDidFinishLaunching(_ notification: Notification) {
        buildMenu()
        buildPanel()
        buildStatusItem()
        checkAccessibility()
        showPanel()
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        showPanel()
        return true
    }

    @objc func showPanel() {
        panel.orderFrontRegardless()
    }

    @objc func togglePanel() {
        if panel.isVisible { panel.orderOut(nil) } else { showPanel() }
    }

    private func buildPanel() {
        let style: NSWindow.StyleMask = [.titled, .closable, .resizable, .utilityWindow, .nonactivatingPanel]
        panel = PalettePanel(contentRect: NSRect(x: 0, y: 0, width: 320, height: 560),
                             styleMask: style, backing: .buffered, defer: false)
        panel.title = "Palette maths"
        panel.level = .floating
        panel.isFloatingPanel = true
        panel.becomesKeyOnlyIfNeeded = true
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        panel.contentView = NSHostingView(rootView: PaletteView())
        panel.setFrameAutosaveName("PalettePanel")
        if panel.frame.origin == .zero, let screen = NSScreen.main {
            let vf = screen.visibleFrame
            panel.setFrameOrigin(NSPoint(x: vf.maxX - 340, y: vf.maxY - 580))
        }
    }

    private func buildStatusItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        if let button = statusItem?.button {
            button.image = NSImage(systemSymbolName: "function", accessibilityDescription: "Palette maths")
            button.target = self
            button.action = #selector(togglePanel)
        }
    }

    private func buildMenu() {
        let mainMenu = NSMenu()
        let appItem = NSMenuItem()
        mainMenu.addItem(appItem)
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "Afficher la palette", action: #selector(showPanel), keyEquivalent: "p")
        appMenu.addItem(withTitle: "Vérifier l'accessibilité", action: #selector(checkAccessibility), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Quitter Palette maths", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu
        NSApp.mainMenu = mainMenu
    }

    @objc func checkAccessibility() {
        let key = kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String
        let trusted = AXIsProcessTrustedWithOptions([key: true] as CFDictionary)
        if !trusted {
            let alert = NSAlert()
            alert.messageText = "Autorisation nécessaire"
            alert.informativeText = """
            Pour que la palette puisse écrire les symboles dans Word ou Pages, macOS doit l'autoriser.

            Réglages Système → Confidentialité et sécurité → Accessibilité → active « Palette maths ».

            Puis quitte et relance la palette.
            """
            alert.addButton(withTitle: "Ouvrir les réglages")
            alert.addButton(withTitle: "Plus tard")
            if alert.runModal() == .alertFirstButtonReturn,
               let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") {
                NSWorkspace.shared.open(url)
            }
        }
    }
}

// MARK: - Lancement

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
